import configparser
import time

import tweepy

print("code is now running...")


def promo_codes():
    config = configparser.ConfigParser()
    config.read('config.ini')

    api_key = config['twitter']['api_key']
    api_key_secret = config['twitter']['api_key_secret']

    access_token = config['twitter']['access_token']
    access_token_secret = config['twitter']['access_token_secret']

    auth = tweepy.OAuthHandler(api_key, api_key_secret)
    auth.set_access_token(access_token, access_token_secret)

    api = tweepy.API(auth)

    while True:
        time.sleep(1)
        twt = api.user_timeline(user_id=, exclude_replies=True,
                                count=1, tweet_mode='extended'
                                )  #enter the twitter account's user id, use: https://tweeterid.com 

        for tweet in twt:
            x = tweet.id
            y = tweet.full_text
            y = y.replace("\n", " ")
            words = y.split(" ")
            c = -1
            c1 = 0
            b = -2
            b1 = -1
            promo_code = words[c:]
            promo_code2 = words[b:b1]

        while len(str(promo_code)) != 24:
            c -= 1
            c1 -= 1
            promo_code = words[c:c1]
            if c == -50:
                break
        while len(str(promo_code2)) != 24 or str(promo_code2) == str(promo_code):
            b -= 1
            b1 -= 1
            promo_code2 = words[b:b1]
            if b == -50:
                break
        if x == 1498403777031856138:  # enter the latest tweet's id, copy it from its url
            pass
        else:
            return promo_code, promo_code2


promo_code = promo_codes()[0]
promo_code2 = promo_codes()[1]
