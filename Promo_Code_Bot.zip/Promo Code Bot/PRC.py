import time
import undetected_chromedriver as uc
from pynput.keyboard import Key, Controller
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.wait import WebDriverWait

from fame_mma_2codes import promo_code, promo_code2

if __name__ == '__main__':

    options = uc.ChromeOptions()
    options.add_argument('proxy-server=106.122.8.54:3128')
    #options.add_argument('')
    #options.add_argument('--user-data-dir=/Users/kiuu/Library/Application Support/Google/Chrome/Default')

    driver = uc.Chrome(options=options)
    url = '' #enter the log in site url 
    driver.get(url)

    def new_account(email, password, code):
        WebDriverWait(driver, 10).until(ec.visibility_of_element_located((By.XPATH, ""))) #enter the xpath of the email input box
        driver.find_element(By.XPATH, "").send_keys(email) #enter the xpath of the email input box
        driver.find_element(By.XPATH, "").send_keys(password) #enter the xpath of the password input box 
        driver.find_element(By.XPATH, "").click() #enter the xpath of a continue (log in) button
        time.sleep(2)
        enter_code(code)


    def enter_code(code):
        driver.get('') #enter the url that the input box is located on
        WebDriverWait(driver, 10).until(ec.visibility_of_element_located((By.XPATH, ""))) #enter the xpath of a input box
        driver.find_element(By.XPATH, "").send_keys(code) #enter the xpath of a input box
        keyboard = Controller()
        keyboard.press(Key.enter)
        keyboard.release(Key.enter)
        time.sleep(1)


    new_account(email='', password='', code=promo_code) #enter email and password for an account
    new_account(email='', password='', code=promo_code2) #enter email and password for another account
